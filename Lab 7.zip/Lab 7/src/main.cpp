#include "TFT_eSPI.h" //include TFT LCD library 

TFT_eSPI tft; //initialize TFT LCD
TFT_eSprite spr = TFT_eSprite(&tft); //initialize buffer

void setup() {
  tft.begin(); //start TFT LCD 
  tft.setRotation(3); //set screen rotation 
  spr.createSprite(TFT_HEIGHT,TFT_WIDTH); //create buffer 
  pinMode(WIO_5S_UP, INPUT); //set switch pin up as input
  pinMode(WIO_5S_DOWN, INPUT); //set switch pin down as input
  pinMode(WIO_5S_LEFT, INPUT); //set switch pin left as input
  pinMode(WIO_5S_RIGHT, INPUT); //set switch pin right as input
  pinMode(WIO_5S_PRESS, INPUT); //set switch pin press as input
}
 
void loop() {
  tft.setTextSize(6); //set text size
  tft.setTextColor(TFT_RED); //set text color 


  if (digitalRead(WIO_5S_UP) == LOW) { //check whether switch is moved up 
   tft.drawCircle(150,150,30,TFT_RED); //display text string if above condition is met 
   delay(1000); //hold text on screen 
  }
  else if (digitalRead(WIO_5S_DOWN) == LOW) {
   tft.drawTriangle(150,150,200,150,165,50, TFT_RED);
   delay(1000);
  }
  else if (digitalRead(WIO_5S_LEFT) == LOW) {
   tft.drawRect(150,150,40,80,TFT_RED);
   delay(1000);
  }
  else if (digitalRead(WIO_5S_RIGHT) == LOW) {
   tft.setTextSize(2); //set text size
   tft.drawString("Marcos Cortes",90,100);
   delay(1000);
  }
  else if (digitalRead(WIO_5S_PRESS) == LOW) {
   tft.drawCircle(150,130,100,TFT_RED);
   tft.drawCircle(100,120,30,TFT_RED);
   tft.drawCircle(200,120,30,TFT_RED);
   tft.drawLine(100,180,200,180,TFT_RED);
   delay(1000);
  }
  spr.pushSprite(0,0); //push to LCD
  delay(200);
}
