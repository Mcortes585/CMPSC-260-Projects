#include <Arduino.h>
#include "TFT_eSPI.h" //include TFT LCD library


TFT_eSPI tft; //initialize TFT LCD 


void setup()
{

  tft.begin(); //start TFT LCD
  tft.setRotation(3); //set screen rotation
    Serial.begin(9600);
    while (!Serial)
        ; // Wait for Serial to be ready
    delay(1000);
    pinMode(WIO_LIGHT, INPUT);
   
}


void loop()
{


    int light = analogRead(WIO_LIGHT);
    Serial.print("Light value: ");
    Serial.println(light);
    if(light > 50){
            tft.fillScreen(TFT_RED);
            tft.setTextSize(4); //set text size
            Serial.println("Lit");
            tft.drawString("It's Lit",50,100); //draw text string
            
    }
    else{
            tft.fillScreen(TFT_BLUE);
            tft.setTextSize(4); //set text size
            Serial.println("Not lit"); 

            tft.drawString("Not Lit",50,100); //draw text string
    }
 
  delay(3000);
}
