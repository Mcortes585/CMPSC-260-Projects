#include <Arduino.h>

void setup()
{
    Serial.begin(9600);

    pinMode(WIO_LIGHT, INPUT);

    while (!Serial)
        ; // Wait for Serial to be ready

    delay(1000);
}

void loop()
{
    int light = analogRead(WIO_LIGHT);
    Serial.print("Light value: ");
    Serial.println(light);

    if (light > 50)
    {
      Serial.println("it's Lit");
    }
    else {
      Serial.println("It's not Lit");
    }
    delay(1000);
}
