#include <Arduino.h>

int ledPin = D0;


void setup() {


  Serial.begin(9600);
  pinMode(WIO_LIGHT,INPUT);
  pinMode(ledPin, OUTPUT);

  while(!Serial);

  delay(1000);


}

void loop() {
  
  int light = analogRead(WIO_LIGHT);
  Serial.print("Light value: ");
  Serial.println(light);

  if (light > 50)
  {
    digitalWrite(ledPin, LOW);
  }
  else {
    digitalWrite(ledPin, HIGH);
  }
  delay(1000);

  
}