#include <Arduino.h>
#include"TFT_eSPI.h" //include TFT LCD library


TFT_eSPI tft; //initialize TFT LCD

void setup() {
  
tft.begin(); //start TFT LCD
tft.setRotation(3); //set screen rotation
tft.fillRect(100, 100, 150, 100, TFT_DARKGREEN); //method adds a filled rectangle to your screen
tft.drawRect(100,100,150,100,TFT_BLACK); //draw rectangle with bordertft.setTextColor(TFT_ORANGE); //set text color

tft.fillTriangle(100,100,247,100,170,10,TFT_MAROON);
tft.drawTriangle(100,100,247,100,170,10,TFT_BLACK); //draw triangle with border
tft.setTextSize(4); //set text size
tft.drawString("My House",0,200); //draw text string

tft.drawRect(115,125,30,30,TFT_GREEN); //draw rectangle
tft.drawRect(205,125,30,30,TFT_GREEN); //draw rectangle

tft.drawRect(160,139,30,60,TFT_BLACK); //draw rectangle
tft.fillRect(160,139,30,60,TFT_PURPLE); //draw rectangle

}

void loop() {
  // put your main code here, to run repeatedly:
}