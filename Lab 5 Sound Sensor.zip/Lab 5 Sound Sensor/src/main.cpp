#include <Arduino.h>


int pinAdc = A0;


void setup()
{
    Serial.begin(115200);
    //Serial.println("Grove - Sound Sensor Test...");


    while(!Serial);


delay(1000);
}


void loop()
{
    int sound = analogRead(pinAdc);
   
    Serial.print("Sound level: ");
    Serial.print(sound);


    if (sound < 500)
{
  Serial.println(" Normal. ");
}
else {
  Serial.println(" Too loud! ");
}
    delay(10);
}
