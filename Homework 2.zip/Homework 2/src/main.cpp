#include <Arduino.h>
#include "TFT_eSPI.h" //include TFT LCD library

TFT_eSPI tft; //initialize TFT LCD 
int pinAdc = A0;


void setup()
{

  tft.begin(); //start TFT LCD
  tft.setRotation(3); //set screen rotation
    Serial.begin(115200);
    //Serial.println("Grove - Sound Sensor Test...");


    while(!Serial);


delay(1000);
}


void loop()
{
    int sound = analogRead(pinAdc);
   
    Serial.print("Sound level: ");
    Serial.print(sound);


    if (sound < 500)
{
  Serial.println(" Normal. ");
  tft.fillScreen(TFT_BLUE);
  tft.setTextSize(4);
  tft.drawString("Sound level: ",0,100);
  tft.drawNumber(sound,125,130);
  tft.drawString("Normal",90,160);
  
}
else {
  Serial.println(" Too Loud!. ");
  tft.fillScreen(TFT_RED);
  tft.setTextSize(4);
  tft.drawString("Sound level: ",0,100);
  tft.drawNumber(sound,125,130);
  tft.drawString("Too Loud!",90,160);
}
    delay(1000);
}
